public class HelloGoodbye {
    public static void main(String args[]){
        String person1 = args[0];
        String person2 = args[1];
        System.out.println("Hello "+person1+" and "+person2+".");
        System.out.println("Goodbye "+person2+" and "+person1+".");
    }
}

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;


public class RandomWord {
    public static void main(String[] args) {
        String champion = StdIn.readString(); // Initialize with an empty string
        
        //`System.out.println(champion);
        int i = 1; // Counter for words read
        while (!StdIn.isEmpty()) {
            String word = StdIn.readString();

            // Knuth's method: Select word with probability 1/i
            if (StdRandom.bernoulli(1.0 / i)) {
                champion = word; 
            }
            i++;
        }

        StdOut.println(champion);
    }
}